use supply_db ;

/*  Question: Month-wise NIKE sales

	Description:
		Find the combined month-wise sales and quantities sold for all the Nike products. 
        The months should be formatted as ‘YYYY-MM’ (for example, ‘2019-01’ for January 2019). 
        Sort the output based on the month column (from the oldest to newest). The output should have following columns :
			-Month
			-Quantities_sold
			-Sales
		HINT:
			Use orders, ordered_items, and product_info tables from the Supply chain dataset.
*/		

SELECT DATE_FORMAT(O.ORDER_DATE,'%Y-%m') AS Month,
SUM(O1.QUANTITY) AS Quantities_sold,
SUM(O1.SALES) AS Sales
FROM ORDERS O 
LEFT JOIN 
ORDERED_ITEMS O1
ON O.ORDER_ID=O1.ORDER_ID
LEFT JOIN
PRODUCT_INFO P
ON O1.ITEM_ID=P.PRODUCT_ID
WHERE P.PRODUCT_NAME LIKE '%Nike%'
GROUP BY 1
ORDER BY 1;


-- **********************************************************************************************************************************
/*

Question : Costliest products

Description: What are the top five costliest products in the catalogue? Provide the following information/details:
-Product_Id
-Product_Name
-Category_Name
-Department_Name
-Product_Price

Sort the result in the descending order of the Product_Price.

HINT:
Use product_info, category, and department tables from the Supply chain dataset.


*/

SELECT P.PRODUCT_ID AS Product_Id, P.PRODUCT_NAME AS Product_Name, C.NAME AS Category_Name,D.NAME AS Department_Name,P.PRODUCT_PRICE AS Product_Price
FROM PRODUCT_INFO P
LEFT JOIN
CATEGORY C
ON P.CATEGORY_ID=C.ID
LEFT JOIN
DEPARTMENT D
ON P.DEPARTMENT_ID=D.ID
GROUP BY 2
ORDER BY 5 DESC
LIMIT 5;


-- **********************************************************************************************************************************

/*

Question : Cash customers

Description: Identify the top 10 most ordered items based on sales from all the ‘CASH’ type orders. 
Provide the Product Name, Sales, and Distinct Order count for these items. Sort the table in descending
 order of Order counts and for the cases where the order count is the same, sort based on sales (highest to
 lowest) within that group.
 
HINT: Use orders, ordered_items, and product_info tables from the Supply chain dataset.


*/

SELECT P.PRODUCT_NAME AS PRODUCT_NAME,SUM(O1.SALES) AS SALES,COUNT(DISTINCT O.ORDER_ID) AS DISTINCT_ORDER_COUNT
FROM ORDERS O
LEFT JOIN
ORDERED_ITEMS O1
ON O.ORDER_ID=O1.ORDER_ID
LEFT JOIN 
PRODUCT_INFO P
ON P.PRODUCT_ID=O1.ITEM_ID
WHERE O.TYPE='CASH'
GROUP BY 1
ORDER BY 3 DESC,2 DESC
LIMIT 10;

-- **********************************************************************************************************************************
/*
Question : Customers from texas

Obtain all the details from the Orders table (all columns) for customer orders in the state of Texas (TX),
whose street address contains the word ‘Plaza’ but not the word ‘Mountain’. The output should be sorted by the Order_Id.

HINT: Use orders and customer_info tables from the Supply chain dataset.

*/

SELECT O.ORDER_ID AS ORDER_ID,O.TYPE AS TYPE,O.REAL_SHIPPING_DAYS AS REAL_SHIPPING_DAYS, 
O.SCHEDULED_SHIPPING_DAYS AS SCHEDULED_SHIPPING_DAYS,O.CUSTOMER_ID AS CUSTOMER_ID,O.ORDER_CITY AS ORDER_CITY,
O.ORDER_DATE AS ORDER_DATE,O.ORDER_REGION AS ORDER_REGION,O.ORDER_STATE AS ORDER_STATE,
O.ORDER_STATUS AS ORDER_STATUS,O.SHIPPING_MODE AS SHIPPING_MODE
FROM ORDERS O
LEFT JOIN
CUSTOMER_INFO C
ON O.CUSTOMER_ID=C.ID
WHERE C.STATE='TX' AND C.STREET LIKE '%Plaza%' AND C.STREET NOT LIKE '%Mountain%'
ORDER BY 1;


-- **********************************************************************************************************************************
/*
 
Question: Home office

For all the orders of the customers belonging to “Home Office” Segment and have ordered items belonging to
“Apparel” or “Outdoors” departments. Compute the total count of such orders. The final output should contain the 
following columns:
-Order_Count

*/

SELECT COUNT(O.ORDER_ID) AS Order_Count
FROM ORDERS O 
LEFT JOIN 
CUSTOMER_INFO C
ON O.CUSTOMER_ID=C.ID
LEFT JOIN 
ORDERED_ITEMS O1
ON O1.ORDER_ID=O.ORDER_ID
LEFT JOIN 
PRODUCT_INFO P
ON P.PRODUCT_ID=O1.ITEM_ID
LEFT JOIN 
CATEGORY C1
ON C1.ID=P.CATEGORY_ID
LEFT JOIN 
DEPARTMENT D
ON D.ID=P.DEPARTMENT_ID
WHERE C.SEGMENT='Home Office' AND (D.NAME='Apparel' OR D.NAME='Outdoors');

-- **********************************************************************************************************************************
/*

Question : Within state ranking
 
For all the orders of the customers belonging to “Home Office” Segment and have ordered items belonging
to “Apparel” or “Outdoors” departments. Compute the count of orders for all combinations of Order_State and Order_City. 
Rank each Order_City within each Order State based on the descending order of their order count (use dense_rank). 
The states should be ordered alphabetically, and Order_Cities within each state should be ordered based on their rank. 
If there is a clash in the city ranking, in such cases, it must be ordered alphabetically based on the city name. 
The final output should contain the following columns:
-Order_State
-Order_City
-Order_Count
-City_rank

HINT: Use orders, ordered_items, product_info, customer_info, and department tables from the Supply chain dataset.

*/

SELECT O.ORDER_STATE AS ORDER_STATE,O.ORDER_CITY AS ORDER_CITY,COUNT(O.ORDER_ID) AS Order_Count, DENSE_RANK() OVER (PARTITION BY O.ORDER_STATE ORDER BY COUNT(O.ORDER_ID) DESC) AS CITY_RANK
FROM ORDERS O 
LEFT JOIN 
CUSTOMER_INFO C
ON O.CUSTOMER_ID=C.ID
LEFT JOIN 
ORDERED_ITEMS O1
ON O1.ORDER_ID=O.ORDER_ID
LEFT JOIN 
PRODUCT_INFO P
ON P.PRODUCT_ID=O1.ITEM_ID
LEFT JOIN 
CATEGORY C1
ON C1.ID=P.CATEGORY_ID
LEFT JOIN 
DEPARTMENT D
ON D.ID=P.DEPARTMENT_ID
WHERE C.SEGMENT='Home Office' AND (D.NAME='Apparel' OR D.NAME='Outdoors')
GROUP BY O.ORDER_CITY,O.ORDER_STATE
ORDER BY O.ORDER_STATE ASC,CITY_RANK ASC,O.ORDER_CITY ASC;

-- **********************************************************************************************************************************
/*
Question : Underestimated orders

Rank (using row_number so that irrespective of the duplicates, so you obtain a unique ranking) the 
shipping mode for each year, based on the number of orders when the shipping days were underestimated 
(i.e., Scheduled_Shipping_Days < Real_Shipping_Days). The shipping mode with the highest orders that meet 
the required criteria should appear first. Consider only ‘COMPLETE’ and ‘CLOSED’ orders and those belonging to 
the customer segment: ‘Consumer’. The final output should contain the following columns:
-Shipping_Mode,
-Shipping_Underestimated_Order_Count,
-Shipping_Mode_Rank

HINT: Use orders and customer_info tables from the Supply chain dataset.


*/

SELECT O.SHIPPING_MODE as Shipping_Mode, count(O.ORDER_ID) AS Shipping_Underestimated_Order_Count,RANK() OVER (PARTITION BY YEAR(O.ORDER_DATE) ORDER BY COUNT(O.ORDER_ID) desc) as Shipping_Mode_Rank
FROM ORDERS O
LEFT JOIN 
CUSTOMER_INFO C
ON O.CUSTOMER_ID=C.ID
WHERE O.Scheduled_Shipping_Days<O.Real_Shipping_Days AND (O.ORDER_STATUS='COMPLETE' OR O.ORDER_STATUS='CLOSED') AND C.SEGMENT='Consumer'
GROUP BY YEAR(O.ORDER_DATE),O.SHIPPING_MODE
ORDER BY YEAR(O.ORDER_DATE),Shipping_Underestimated_Order_Count DESC;
-- **********************************************************************************************************************************





